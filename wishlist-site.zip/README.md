# Вішліст з бронюванням подарунків (Vercel + Upstash Redis)

1. Завантажте вміст цієї папки в новий репозиторій GitHub (папки `api` і `public`, файл `vercel.json`).
2. Vercel → Add New → Project → виберіть цей репозиторій → Deploy.
3. У проєкті: Storage → Create Database → Upstash Redis (Free) → Connect to Project. Змінні `KV_REST_API_URL` і `KV_REST_API_TOKEN` додадуться самі.
4. Settings → Environment Variables → додайте `ADMIN_PASSWORD` (ваш пароль власника).
5. Deployments → ⋯ біля останнього деплою → Redeploy.
6. Перевірка: `ваш-сайт/api/health` має показати `"ok":true`, `"storage":true`, `"adminPassword":true`.

Власник: унизу сторінки значок 🔑 → пароль → можна додавати, змінювати, видаляти бажання й бачити, хто що забронював.
Гості: «Забронювати» (скасувати бронь може лише той, хто її зробив, з того ж пристрою).
